export class Payee{
    name:string="";
    accountNumber:string="";
    nickName:string="";
}