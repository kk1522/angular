import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PayeeMenuComponent } from './payee-menu.component';

describe('PayeeMenuComponent', () => {
  let component: PayeeMenuComponent;
  let fixture: ComponentFixture<PayeeMenuComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PayeeMenuComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PayeeMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
